Here are the two clan uk Hlaf-Life skins, as made by [UK]Timbo`s fair hand:)

There are two skins here, CLANUK, and UKSARG

Each skin has two files, a bmp and a mdl, both files of each skin need to be placed 
be placed in a folder named exactly the same, so:

Clanuk.mdl & Clanuk.bmp should be placed in a folder called Clanuk.
This folder should then be placed in the following folder in your half life directory:

Half Life\Valve\Models\Player

The same should be done with with UKsarg.


The Clanuk skin is for all clan members, UKSARG is for the HL team, to be used in
clan games.