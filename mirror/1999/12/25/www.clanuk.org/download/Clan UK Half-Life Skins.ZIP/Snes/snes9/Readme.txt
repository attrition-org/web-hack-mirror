Snes9x: The Portable Super Nintendo Entertainment System Emulator
=================================================================
v1.16a 21-DEC-1998
==================

Home page: www.snes9x.com

Contents
========
Changes Since Last Release
Introduction
What's Emulated
What's Not
What You Will Need
Getting Started/Command Line Options
Keyboard Controls
Joystick Support
Netplay Support
Super FX
Problems With ROMs
Sound Problems
Converting ROM Images
Speeding up the Emulation
Credits

Changes Since Last Release
==========================

1.16
- Fixed a case where the -forcelorom option didn't work - the case was
  required for Formation Soccer which claims in its ROM header to use the 
  same memory map as Super FX ROM, it doesn't.
- Pulled apart a real SNES using a crowbar (great fun), just to look at what
  speed the SPC700 is actually clocked at for more acturate relative emulation
  speed.
- Implemented SPC700 cycle counting in the hope the improved timing would fix
  Tales'; no such luck but at least the -ratio option is obsolete now.
- Implemented executing SPC700 instructions during DMA, fixes BS Zelda,
  Goal and Smurfs 2 lock up at start and music pausing briefly when ROMs do 
  lots of DMA, usually between game screens.
- Scrapped the i386 asm SPC700 code - it was the cause of the music not 
  restarting after a battle in Chrono Trigger and FF3 and I didn't realise
  because the bug had already occurred in the test freeze-file I had.
  Thanks to John Stiles for pointing out that the Mac port didn't have the
  missing music problem in the first place.
- Fixed RGB subtraction bug on displays with only 5 bits for green, e.g. RGB555
  displays. The GREEN_HI_BIT variable was always set to a value for 6 bit
  green displays.
- Added the SA-1 memory map, still a long way to go before any SA-1 game will 
  run.
1.15
- Jumped versions to keep in sync with the DOS port release.
1.14
- Improved 8-bit sound generation slightly, but it still sounds very poor
  compared to 16-bit sound.
1.13
- Implemented the Tales of Phantasia memory map using the information supplied
  by zsKnight. Had to also implement a de-interleave routine to work around
  a ROM feature and Snes9x CPU instruction fetching implementation detail.
- Added a frames-per-second on-screen display option.
- Fixed the final glitch bug with the Mario Kart track display - the byte code
  for the termination of the DSP1 raster command wasn't been recognised.
- Disabled a NMI/DMA hack for Rise of the Robots, was causing problems for
  Mario Kart and 'Robots wasn't working correctly anyway.
- Optimised the mode 7 rendering a little.
- Changed tile rendering code to use offsets into screen buffer rather than
  direct pointers ready for z-buffer implementation.
1.12
- Changed V-blank NMI to occur immediately after a WAI instruction, Toy Story 
  required this.
- Fixed reading of H-DMA line counter register, Top Gear 3000 needed this.
- Ripped off large parts of ZSNES's DSP1 code (with _Demo_'s and zsKnight's
  approval). Now Mario Kart works almost 100%.
- Added a check to see if a vertical scanline IRQ register change will cause
  a H-IRQ later on the current scanline. Pilot Wings needed this.
- Fixed possible crash bug in clip window code when both windows had two
  spans. Could actually cause Chrono Trigger to crash the emulator.
- Fixed a lock-up problem with the C Super FX code, Star Fox and executing
  a few 'FX instructions per scan-line (required for Winter Gold).

Introduction
============

Snes9x is a portable, freeware Super Nintendo Entertainment System (SNES)
emulator. It basically allows you to play most games designed for the SNES
and Super Famicom Nintendo game systems on your PC or Workstation; which
includes some real gems that were only ever released in Japan.

Snes9x is the result of well over a year and a half's worth of part-time
hacking, coding, recoding, debugging, divorce, etc. (just kidding about the
divorce bit). Snes9x is coded in C++, with three assembler CPU emulation
cores on the i386 Linux and Windows ports.

Snes9x is better than a real SNES:
o Freeze a game at any position, then restore the game to that exact spot at
  a later date - ideal for saving a game just before a difficult bit.
o Built-in cheat cartridge.
o Built-in peripheral emulation. The SNES mouse, Multi-player 5 and SuperScope
  external add-ons are all emulated, they cost extra money with a real SNES.
o Stereo sound - yes I know the SNES produced stereo sound, but who actually
  paid the inflated price for the special lead just so you could hear it?
o No more cartridge contact cleaning!
o Some SNES hardware features that be turned on and off during game play,
  games might be using one of these features to deliberately make a section
  of the game more difficult. Easy, just turn the feature off.
o Networked game play.

Snes9x is worse than a real SNES:
o Unless your computer is very fast (Pentium II+), some games just can't
  hit every frame being rendered and the emulator starts to omit rendering
  some frames to keep the emulator running at a constant speed - to you
  it appears as if the graphics aren't moving as smoothly as they should.
o Not all games work; bugs and missing features cause some games to fail to
  work or renders them un-playable.
o You have to wait for your computer to boot before you can play games,
  no waiting on the real SNES!
o The SNES has an analog low-pass sound filter that give a nice bass to
  all the sounds and music - Snes9x doesn't emulate this. If you have
  a posh sound card, you could try fiddling with it mixer controls to produce
  a similar effect. Lowering the playback rate can have a similar effect.

What's Emulated
===============
- The 65c816 main CPU.
- The Sony SPC700 sound CPU.
- SNES variable length cycles.
- 8 channel DMA and H-DMA (raster effects).
- All background modes, 0 to 7.
- Sound DSP, with eight 16-bit stereo channels, compressed samples, hardware
  attack-decay-sustain-release volume processing, echo, pitch modulation
  and digital FIR sound filter.
- 8x8, 16x8 and 16x16 tile sizes, flipped in either direction.
- 32x32, 32x64, 64x32 and 64x64 screen tile sizes.
- H-IRQ, V-IRQ and NMI.
- Mode 7 screen rotation, scaling and screen flipping.
- Vertical offset-per-tile in modes 2, and 4.
- 256x224, 256x239, 512x224, 512x239, 512x448 and 512x478 SNES screen
  resolutions.
- Sub-screen and fixed colour transparency effects.
- Mosaic effect.
- Single and dual graphic clip windows, with all four logic combination modes.
- Colour effects only inside a window.
- 128 8x8, 16x16, 32x32 or 64x64 sprites, flipped in either direction.
- SNES palette changes during frame (15/16-bit internal rendering only).
- Super FX, a 21/10MHz RISC CPU found in the cartridge of several games.
- SNES mouse.
- SuperScope (light gun) emulated using computer mouse.
- Multi-player 5 - allowing up to five people to play games simultaneously on
  games that support that many players.
- Game-Genie, Action Replay and Gold Finger cheat codes.
- Multiple ROM image formats, with or without a 512 byte copier header.
- Single or split images, compressed using gzip, and interleaved in one of two
  ways.
- Auto S-RAM (battery backed RAM) loading and saving.
- Freeze-game support, now portable between different Snes9x ports.

What's Not
==========
- Only partial DSP1 support, enough to play Mario Kart but no more. The DSP1
  is a math co-processor chip that was inside the cartridge of some games,
  notably Mario Kart and Pilot Wings.
- Any other odd chips that manufactures sometimes placed inside the
  cartridge to enhance games and as a nice side-effect, also act as an 
  anti-piracy measure.
- Direct colour mode - uses tile and palette-group data directly as RGB value.
- Pseudo hi-res. mode - SNES hardware uses interpolation to give apparent
  increase in horizontal resolution, use the TV mode to get the same effect.
- Mosaic effect on mode 7.
- A couple of SPC700 instructions that I can't work out what they should do.
- Fixed colour and mosaic effects in SNES hi-res. (512x448) modes.
- Offset-per-tile in mode 6. Luckily I haven't found a game that uses it, yet.
- Horizontal offset-per-tile in modes 2, 4 and 6. Just noticed that Chrono
  Trigger uses that.
- Cycle counting on SPC700 emulation.
- Executing SPC700 instructions during SNES DMA operation.
- Exact sound CPU and sound generation synchronisation.
- Various pixel priority problems with sprites and transparency effects.

What You Will Need
==================

CPU
---
Faster the better, but 486DX4 100 minimum when using 8-bit graphics and
minimal or no sound, Pentium 166 or higher for transparency effects and
Pentium 200 or higher for Super FX games.

Memory
------
16Mb or more for Linux. Sun workstations shouldn't have a problem.

Screen
------
X Window System ports needs an 8, 15, 16, 24 or 32 bit X server running;
transparency effects are available at all depths, but don't look good with
only an 8-bit display. For maximum emulation speed, have the X server switched
to 8-bit and don't enable transparency effects, or 15 or 16-bit with
transparency effects enabled.

The Linux SVGA port is very limited at the moment due to no 16-bit screen
modes being supported on my two main development machines. However, the
Linux X Window System version now has a full-screen mode, so there's hopefully
no need to use the SVGA version.

Disk Space
----------
1Mb for the emulator.

Software
--------
Access to SNES ROM images in *.smc, *.sfc, *.fig or *.1, *.2, or sf32xxxa,
sf32xxxb, etc., format otherwise you will have nothing to run!

Please note, it is illegal in most countries to have commercial ROM images
without also owning the actual SNES ROM cartridge.

Getting Started
===============

From a shell just type:
snes9x <ROM filename>

to start the X Window System port or

ssnes9x <ROM filename>

to start the Linux SVGA port.

ROM images are normally loaded from the directory ./roms. This can be
changed by specifying a pathname with the image name or setting the
environment variable SNES96_ROM_DIR to point to a different directory.

Freeze game files and S-RAM save files are normally read from and written to
the directory $HOME/.snes96_snapshots.  This can be changed by setting the
environment variable SNES96_SNAPSHOT_DIR to point to a different directory.

To enable full-screen mode on the Linux X Window System and SVGA ports, Snes9x
needs special system access permissions to allow it to write directly to video
RAM and alter video chipset register values. In the directory where Snes9x is
located, typing:

su root
chown root snes9x ssnes9x
chmod 4755 snes9x ssnes9x

will give the binaries the required access.

Some command line flags are available:

Graphics options:
-tr or transparency (default: off)
   Enable transparency effects, also enables 16-bit screen mode selection.
   Transparency effects are automatically enabled if the depth of your X 
   server is 15 or greater. 
-16 or -sixteen (default: off)
   Enable 16-bit internal screen rendering, allows palette changes but no
   transparency effects.
-hires or -hi (default: lo-res.)
   Enable support for SNES hi-res. and interlace modes. USE ONLY IF GAME
   REQUIRES IT (FEW DO) BECAUSE IT REALLY SLOWS DOWN THE EMULATOR.
-y or -interpolate (default: off)
   Enables 'TV mode', hires support, 16-bit internal rendering and
   transparency effects. TV mode scales the SNES image by x2 by inserting an
   extra blended pixel between each SNES pixel and 80% brightness 'scan-lines'
   between each horizontal line. The result looks very nice but needs a fast
   machine. Use with the full-screen X mode and a 15 or 16 depth X server,
   or the SVGA port for fastest operation.
-nms or -nomodeswitch (default: switch modes)
   The Linux X Windows System port can change the screen resolution when
   switching to full-screen mode so the SNES display fills the whole screen.
   Specify this option to stop it if causes you problems.
-scale or -sc (default: off)
   Stretch the SNES display to fit the whole of the computer display.
   Linux X Window System full-screen mode or SVGA port only. Use only if you
   have a very fast machine.
-displayframerate or -dfr
   Display a frame rate counter superimposed over the bottom, left-hand corner
   of the SNES display. The value before the slash (/) indicates how many
   frames per second are being rendered compared to a real SNES, the value of
   which is displayed after the slash.

Sound options:
-ns or -nosound
   Disable sound CPU emulation and sound output, useful for the few ROMs
   where sound emulation causes them to lock up due to timing errors.
-sk 0-3 or -soundskip 0-3 (default: 0)
   ONLY USED IF SOUND IS DISABLED. 
-stereo or -st (default: stereo)
   Enable stereo sound output.
-mono (default: stereo)
   Enable mono sound output. Faster, but doesn't sound as nice.
-r 0-7 or -soundquality or -sq 0-7 (default: 4)
   Sound playback rate/quality:
       0 - disable sound, 1 - 8192, 2 - 11025, 3 - 16500, 4 - 22050 (default),
       5 - 29300, 6 - 36600, 7 - 44000.
-b size or -buffersize size or -bs size (default: auto-select)
   Sound playback buffer size in bytes 128-4096.
-envx or -ex (default: off)
   Enable volume envelope height reading by the sound CPU. Can cure sound
   repeat problems with some games (e.g. Mortal Kombat series), while causing
   others to lock if enabled (eg. Bomberman series).
-nosamplecaching or -nsc or -nc (default: on)
   Disable decompressed sound sample caching. Decompressing samples takes time,
   slowing down the emulator. Normally the decompressed samples are saved
   just in case they need to be played again, but the way samples are stored
   and played on the SNES, it can result in a click sound or distortion when
   caching samples with loops in them.
-noecho or -ne (default: on)
   Turn off sound echo and FIR filter effects. Processing these effects can
   really slow down a non-MMX Pentium machine due to the number of calculations
   required to implement these features.
-ratio 1+ or -ra 1+ (default: 2) (OBSOLETE)
   Ratio of 65c816 to SPC700 instructions. The value is no longer used
   because SPC700 cycle counting is now implemented giving much more acturate 
   timing.
-nomastervolume or -nmv (default: on)
   Disable emulation of the sound DSP master volume control. Some ROMs set
   the volume level very low requiring you to turn up the volume level of
   your speakers introducing more background noise. Use this option to
   always have the master volume set on full and to by-pass a bug which
   prevents the music and sound effects being heard on Turrican.

Cheat options:
-gg <code> or -gamegenie <code>
   Supply a Game Genie code for the current ROM. Up to 10 codes can be in
   affect at once. Game Genie codes for many SNES games are available from:
   http://game-genie.nvc.cc.ca.us
-ar <code> or -actionreplay <code>
   Supply a Pro-Action Reply code for the current ROM. Up to 10 codes can be in
   affect at once. At the moment, codes which alter RAM do not work.
-gf <code> or -goldfinger <code>
   Supply a Gold Finger code for the current ROM. Up to 10 codes can be in
   affect at once.

Speed up/slow down options: (See "Speeding Up The Emulation")
-f <frame skip count> or -frameskip <frame skip count> (default: auto-adjust)
   Set this value to deliberately fix the frame skip rate and disable auto-
   speed regulation. Use a larger value faster emulation but more jerky
   movement and a smaller value for smooth but slower screen updates.
   Use '+' and '-' keys to modify the value during a game.
   Ideal for some Super FX games that confuse the auto-adjust code or
   for games that deliberately flash the screen every alternate frame.
-frametime <time in milliseconds> or -ft <time in milliseconds>
   (default: 16.6ms NTSC games and 20ms for PAL games)
   If auto-adjust frame skip option is in effect, then the emulator will try
   to maintain a constant game and music speed locked to this value by skipping
   the rendering of some frames or waiting until the required time is reached.
   Increase the value to slow down games, decrease it to speed up games.
   During a game the value can be adjusted in millisecond steps by pressing
   Shift '-' or Shift '+'.
-h <0-200> or -cycles <0-200>(default: 100)
   Percentage of CPU cycles to execute per scan line, decrease value to
   increase emulation frame rate. Most ROMs work with a value of 85 or above.
-j or -nojoy
   Turn off joystick, SideWinder and GrIP detection (joystick polling on the
   PC slows the emulator down).

ROM image format options:
-i or -interleaved (default: auto-detect)
   Force interleaved ROM image format.
-i2 or -interleaved (default: can't be auto-detected)
   Force alternate interleaved format (i.e. most Super FX games).
-hirom or -fh or -hr (default: auto-detect)
   Force Hi-ROM memory map for ROMs where the Hi-ROM header test fails.
-lorom or -fl or -lr (default: auto-detect)
   Force Lo-ROM memory map for ROMs where the Hi-ROM header test fails)
-header or -hd (default: auto-detect)
   Force the detection of a ROM image header. Some ROM images have been 
   hand-edited to remove unused space from the end of the file; if the
   resultant image size is not a multiple of 32k then Snes9x can't 
   auto-detect the presense of a 512 byte ROM image header.
-noheader or -nhd (default: auto-detect)
   Force Snes9x into thinking no ROM image header is present. See -header
   above.
-p or -pal (default: auto-detect)
   Fool ROM into thinking this is a PAL SNES system and adjust frame time
   to 20ms (50 frames per second)
-n or -ntsc (default: auto-detect)
   Fool ROM into thinking this is a NTSC SNES system and adjust frame time
   to 16.7ms (60 frames per second)
-l or -layering (default: off)
   Swap background layer priorities from background involved in sub-screen
   addition/subtraction. Can improve some games play-ability - no need to
   constantly toggle background layers on and off to read text/see maps, etc.
   Toggle feature on and off during game by pressing '8'.
   Not used if transparency effects are enabled.
-l <freeze game file name> or -loadsnapshot <freeze game file name>
   Load snapshot file and restart game from saved position.
-nh or -nohdma (default: H-DMA enabled)
   Turn off the H-DMA emulation. Pressing '0' during a game toggles H-DMA on
   and off.
-n or -nospeedhacks (default: speed hacks)
   Turn off a couple of speed hacks. The hacks boost the speed of many ROMs
   but cause problems a few ROMs.
-nw or -nowindows (default: graphics windows emulated)
   Disable graphics windows emulation. Use 'backspace' key during a game to
   toggle the emulation on and off.

Joystick options:
-joymap[1|2|3|4] followed by 8 numbers
   Specify the SNES joypad buttons to Linux joystick driver buttons mapping for
   each of the four supported joypads.
   Specify the Linux joystick button number for the corresponding SNES button
   in the following order: A, B, X, Y, TL, TR, Start and Select
   The default map is: 1 0 4 3 6 7 8 9 
   which is suitable for Sidewinder gamepads.
-s or -swap
   Swap emulated joy-pad 1 and 2 around, pressing '6' during a game does the
   same thing.
-j or -nojoy
   Turn off joystick, SideWinder and GrIP detection (joystick polling on the
   PC slows the emulator down).

For example, to start a game called "mario", with sound, and transparency
effects, type:

snes9x -tr mario.smc

Keyboard Controls
=================

While the emulator is running:
'Escape'                 Quit the emulator
'Pause' or 'Scroll Lock' Pause the emulator
Alt+'f' or PrtSc	 Toggle the X11 port full-screen mode on and off.

Joy-pad 1:
'up' or 'u'             Up direction
'down', 'j' or 'n'      Down direction
'left' or 'h'           Left direction
'right' or 'k'          Right direction
'a', 'v' or 'q'         TL button
'z', 'b' or 'w'         TR button
's', 'm' or 'e'         X button
'x', ',' or 'r'         Y button
'd', '.' or 't'         A button
'c', '/' or 'y'         B button
'return'                Start button
'space'                 Select button

'Mouse left'            Mouse left button or SuperScope fire button.
'Mouse right'           Mouse right button or SuperScope cursor button.

'tab'                   SuperScope turbo toggle switch.
'`'                     SuperScope pause button.

'0'                     Toggle H-DMA emulation on/off.
'1'                     Toggle background 1 on/off.
'2'                     Toggle background 2 on/off.
'3'                     Toggle background 3 on/off.
'4'                     Toggle background 4 on/off.
'5'                     Toggle sprites (sprites) on/off
'6'                     Toggle swapping of joy-pad one and two around
'7'			Rotate between Multi-player 5, mouse on port 1,
                        mouse on port 2 and SuperScope emulation.
'8'                     Toggle background layer priorities for backgrounds
                        involved in sub-screen addition/subtraction.
'9'			Toggle transparency effects on and off - only if
			16-bit screen mode selected.
'Backspace'		Toggle emulation of graphics window effects on/off.

'-'			Decrease frame redraw skip rate
'+'			Increase frame redraw skip rate
			The sequence is auto-frame rate adjust, render every
                        frame, render 1 frame in two, render 1 frame in three,
                        render 1 frame in four, etc.

Shift+'-'		Decrease frame time in 1ms steps.
Shift+'+'		Increase frame time in 1ms steps.
			The frame time value is the average length of time a
			single frame should take to emulate - works only if
			the auto-frame rate adjust is operational.
			The code will skip the rendering of some
			frames in order to try and reach the required value.
Shift+'F1-F10'          Quick save a freeze game file.
'F1-F10'                Quick load a freeze game file, restoring a game to an
                        exact position.
Alt+'F2'                Load a game's saved position.
Alt+'F3'                Save a game's position.

Alt+'F4' -> 'F11'	Toggle sound channels on/off.
Alt+'F12'		Turn on all sound channels.

Joystick Support
================

The Linux port now makes use of the new v1.x joystick kernel drivers written
by Vojtech Pavlik (vojtech@ucw.cz) to allow the use of a wide varity of
different joystick/joypad types to control SNES games.

Older versions of the drivers are included in recent development Linux
kernels. Download the lastest driver version from 
http://atrey.karlin.mff.cuni.cz/~vojtech/joystick/

Refer to the documentation that comes with the drivers to enable support for
your type of joystick/pad in Snes9x.

Netplay Support
===============

The Linux and UNIX ports of Snes9x support networked game-play, where
each player of a multi-player SNES game can be on their own workstation.
Due to the nature in which the emulated SNES games where written and speed
general lack of speed of the Internet, only local-area network game play is
possible.

Start the s9xserver process on one machine, then start snes9x on each
workstation giving the extra command-line flag -server <hostname> where
<hostname> is the name of the machine where the s9xserver process was
started. Is is also possible to specify the server name by setting the
environment variable S9XSERVER to the server hostname.

Snes9x normally uses network port 6096 by default, this can be changed by
specifying -port <port num> on the command line of the server and snes9x,
or by setting the environment variable S9XPORT.

The first snes9x session to connect to the server becomes player 1 and dicates
what ROM all other snes9x clients will have to run before connecting to the
server. The second client to connect becomes player 2, and so on. As each new
snes9x client process connects to the server, existing games in progress are
reset to the beginning to keep everyone in sync.

Some SNES games randomise game play and screen layout using data from the SNES
sound chip, notably the Bomberman series. Since Snes9x doesn't keep the sound
generation in exact synchronisation with the CPU emulation (if it did you'd
keep hearing breaks in the sound), you find such games can vary the screen
layout and baddy movement between Snes9x sessions given that all other
external input is identical, thus making it difficult to play multi-player
networked sessions with these games. To network play such games, either switch
off sound (-ns) or wait until I provide a re-sync option in the next release.

Super FX
========

The Super FX is a 10/21MHz RISC CPU developed by Argonaut Software used as a
game enhancer by several game tiles. Support is still buggy and I've no
idea what the problem is. Oh well, may be one day... Anyway, games that work:
Yoshi's Island (best single-player game on SNES, if you like platform games),
Doom, Winter Gold and Dirt Trax FX.

Games that don't work:
StarFox, StarFox 2, Stunt Race FX, Vortex.

All games that actually work are extremely playable on my 200MHz K6 desktop
machine. Frame rates will suffer for folks with slower machines.

Lots of Super FX ROM images available are in an odd interleaved format that
I haven't worked out how to auto-detect. If your ROM image isn't working try
using the -i2 command line flag.

Problems With ROMs
==================

If the emulator just displays a black screen for over 10 seconds, then one
of the following could be true:

1) If its a Super FX game, chances are its in interleaved2 format, try the -i2
   switch.
2) Someone has edited the Nintendo ROM information area inside the ROM image
   and Snes9x can't work out what format ROM image is in. Try playing
   around with the ROM options: -i, -fl, -fh, -hd, -nhd.
3) The ROM image is corrupt. If you're loading from CD, I know it might
   sound silly, but is the CD dirty?
4) The original SNES ROM cartridge had additional hardware inside that is not
   emulated yet and might never be - e.g. Street Fighter 2 Alpha,
   Megaman X2 and Megaman X3.

Sound Problems
==============

No sound coming from any SNES game using Snes9x? Could be any or all of
these:

- Snes9x couldn't open the sound device (/dev/dsp) when it started (Snes9x
  should display an error message), a permissions problem, the device doesn't
  exist or some other process already has the sound device open.
- The kernel doesn't support your sound hardware (Linux barely supports the
  sound card in my new laptop, I'm stuck with 8-bit sound only at the moment).
- You haven't got the volume control on your speakers turned down, have you?

General sound problems:

- Sound samples keep repeating or don't switch off, especially ones
  that play lots of speech samples, try -envx (e.g. Mortal Kombat series).
- Sound quality is poor on all games. You have a noisy sound card (usually 
  cheap cards) or one that Linux only supports at 8-bit.

Converting ROM Images
=====================

If you have a ROM image in several pieces, simply rename them so their
filename extensions are numbered: e.g. game.1, game.2, etc. Then, when
loading the ROM image, just specify the name of the first part; the remaining
parts will be loaded automatically.

If they are already in the form sf32xxxa, sf32xxxb, etc., you don't even have
to rename them; just specify the name of the first part, as above.

Emulation speed
===============

Emulating an SNES is very compute intensive, with its two or three CPUs,
an 8 channel digital sound processor with real-time sound sample decompression
and stereo sound, two custom graphics processors, etc.

If you only have a 486 machine, you will need to stick to using only 8-bit
graphics and minimal or no sound:

With sound:
snes9x -ne -r 1 -m 2 -mono <rom filename>

Without sound:
snes9x -ns -m 2 <ROM filename>.

Disabling the joystick support will also help (-j).

For maximum speed, if you're using the X Window System port, make sure your
X server is set to depth 8 and transparency effects are not enabled, or your
X server is set to depth 15 or 16 if you want transparency effects.

If you want to use the TV mode (-y), switching to a full-screen display is
usually fastest with the X server set to depth 15 or 16.

Don't enable the scale option and don't resize the window on the X Windows
port.

Users with slower Pentium machines might want to turn off echo and digital
FIR filter effects, due to the number of multiply operations needed to
implement them. Use -ne option.

Got a big throbbing beast of a CPU under the cover of your computer? These
options will sort out the men from the boys:
snes9x -y -sc -r 5 -nc <ROM filename>

Credits
-------

- Jerremy Koot for all his hard work on current and previous versions of 
  Snes96, Snes97 and Snes9x.
- Ivar for the original Super FX C emulation, DSP1 emulation work and 
  information on both chips.
- zsKnight and _Demo_ for the Intel Super FX assembler code.
- zsKnight and _Demo_ for all the other ideas I've nicked off them; they've
  nicked lots of my ideas and information too!
- DiskDude's SNES Kart v1.6 document for the Game Genie(TM), Gold Finger and
  Pro Action Replay cheat system information.
- Lord ESNES for some nice chats and generally useful stuff.
- Lee Hyde (lee@jlp1.demon.co.uk) for his quest for sound information and 
  the Windows 95 icon.
- Shawn Hargreaves for the rather good Allegro 3.0 DOS library.
- Robert Grubbs for the SideWinder information - although I didn't use his
  actual driver in the end.
- Steve Snake for his insights into SNES sound sample decompression.
- Vojtech Pavlik for the Linux joystick driver patches.
- Maciej Babinski for the basics of Linux's DGA X server extensions.
- Alexander Larsson for the GGI Linux port code.
- Harald Fielker for the sound interpolation code (not included in this 
  release due to problems).

Nintendo is a trademark.
Super NES, SuperScope and Super FX are a trademarks of Nintendo. 
Sun, Solaris and Sparc are all trademarks of Sun Microsystems, Inc.  
Game Genie is a trademark of Lewis Galoob Toys, Inc.
MS-DOS and Windows 95 are trademarks of Microsoft Corp.
Intel, Pentium and MMX are all trademarks of Intel Corp.
Sony is a trademark of Sony Corp.
UNIX is a trademark of someone, I forget who, but its not AT&T, they sold it.

------------------------------------------------------------------------------
Gary Henderson
gary@snes9x.com
